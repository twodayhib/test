import logging
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
import base64
import urllib.parse

# Enable logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    level=logging.INFO)
logger = logging.getLogger(name)

# Base64 decoding function
def decode_base64(update, context):
    try:
        encoded_message = ' '.join(context.args)
        decoded_message = base64.b64decode(encoded_message).decode('utf-8')
        update.message.reply_text(f"Base64 Decoded message: {decoded_message}")
    except Exception as e:
        update.message.reply_text("Error decoding Base64. Please make sure it's a valid Base64 encoded string.")

# Caesar Cipher decoding function
def caesar_cipher_decode(text, shift):
    result = ""
    for i in range(len(text)):
        char = text[i]
        if char.isupper():
            result += chr((ord(char) - shift - 65) % 26 + 65)
        elif char.islower():
            result += chr((ord(char) - shift - 97) % 26 + 97)
        else:
            result += char
    return result

def decode_caesar(update, context):
    try:
        if len(context.args) < 2:
            update.message.reply_text("Usage: /caesar <shift> <message>")
            return

        shift = int(context.args[0])
        message = ' '.join(context.args[1:])
        decoded_message = caesar_cipher_decode(message, shift)
        update.message.reply_text(f"Caesar Decoded message: {decoded_message}")
    except Exception as e:
        update.message.reply_text("Error decoding Caesar Cipher. Please provide a valid shift and message.")

# URL decoding function
def decode_url(update, context):
    try:
        encoded_message = ' '.join(context.args)
        decoded_message = urllib.parse.unquote(encoded_message)
        update.message.reply_text(f"URL Decoded message: {decoded_message}")
    except Exception as e:
        update.message.reply_text("Error decoding URL. Make sure it's a valid URL-encoded string.")

# Start command
def start(update, context):
    update.message.reply_text("Welcome to the Decode Bot! Send /base64 <encoded_message>, /caesar <shift> <message>, or /url <encoded_url> to decode.")

# Help command
def help_command(update, context):
    update.message.reply_text("Available commands:\n"
                              "/base64 <encoded_message> - Decode a Base64 encoded string\n"
                              "/caesar <shift> <message> - Decode a Caesar Cipher text with a shift value\n"
                              "/url <encoded_url> - Decode a URL-encoded string\n"
                              "/help - Show this help message")

# Error handler
def error(update, context):
    logger.warning(f"Update {update} caused error {context.error}")

# Main function
def main():
    # Use your BotFather token here
    TOKEN = "7779037777:AAHNp_iyGyFlO2Ayi6jM_cbGaywyP4YIWec"

    # Create an Updater object with your bot's token
    updater = Updater(TOKEN, use_context=True)

    # Get the dispatcher to register handlers
    dp = updater.dispatcher

    # Commands
    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CommandHandler("help", help_command))
    dp.add_handler(CommandHandler("base64", decode_base64))
    dp.add_handler(CommandHandler("caesar", decode_caesar))
    dp.add_handler(CommandHandler("url", decode_url))

    # Log all errors
    dp.add_error_handler(error)

    # Start the bot
    updater.start_polling()

    # Run the bot until you press Ctrl+C
    updater.idle()

if name == 'main':
    main()