pip install python-telegram-bot
